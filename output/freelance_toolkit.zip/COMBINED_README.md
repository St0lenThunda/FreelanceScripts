# Freelance Toolkit
A collection of Python tools for freelancers.

# Excluded Tools
The following tools are excluded from the combined README:

- output
- .venv
- .git
- bin

## Csv_json_converter
# 🧮 CSV ⇄ JSON Tool
[← Back to Main README](../README.md)

> ## Purpose
> A two-way data converter built in Python. Use it to transform:

- CSV → JSON (`c2j`)
- JSON → CSV (`j2c`)

Supports:
...

## Readme_updater
# README Updater

> ## Purpose
> This script, `readme_updater.py`, provides a modular framework for dynamically updating the main project README. It allows for the addition of multiple tasks, such as generating a tool table, and makes the process extensible for future enhancements.

## Features

- **Modular Task System**: Tasks are encapsulated in classes, making it easy to add new functionality.
- **Automatic Table Generation**: Extracts tool information from their `README.md` files and generates a Markdown table.
- **Customizable Markers**: Inserts the table between `<!-- TOOL_TABLE_START -->` and `<!-- TOOL_TABLE_END -->` markers in the main README.
...

## Scraper
# 🌐 Simple Web Scraper
[← Back to Main README](../README.md)

> ## Purpose
>  Fetch all titles from [Hacker News](https://news.ycombinator.com
). Fetches inner text and links of  `<a>` elements inside `<span class="titleline">`.

## 🚀 Usage

```bash
...

## Executioner
# Executioner Tool

> ## Purpose
>
> The `executioner.py` script automates the process of making Python scripts executable and symlinking them into a `bin/` directory for easy access via the system PATH.

## Features

- **Executable Conversion**: Automatically applies executable permissions to Python scripts.
- **Symlink Creation**: Creates symlinks in a `bin/` directory for easy command-line usage.
...

## Package_toolkit
# 🧰 Package Toolkit

> ## Purpose 
> The Package Toolkit is a utility script designed to create a zip archive of your freelance tools, excluding unnecessary files. It also generates a combined README summarizing the tools in the project.

## Features

- Dynamically generates a combined README summarizing tool READMEs.
- Excludes directories and files marked with `.excluded` or matching predefined patterns.
- Creates a zip archive of the project for easy distribution.
...

## Debug_demo
# 🪛 Scraper Debug Demo Tool

[← Back to Main README](../README.md)

> ## Demo - Purpose
>This tool demonstrates a real-world debugging and refactoring process taken from the `scraper/simple_scraper_tool.py`. It includes both a **broken** and a **fixed** version of the scraper to illustrate how problems were identified and solved in a freelance-style workflow.

---

## 🐛🔍 Buggy Version: `scraper_buggy_tool.py`
...

