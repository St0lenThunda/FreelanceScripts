#!/usr/bin/env python3
"""
package_toolkit.py

Creates a zip archive of your freelance tools, excluding unnecessary files.
"""

import os
import zipfile
from pathlib import Path

# Update the root directory of the project to reflect the new location
PROJECT_ROOT = Path(__file__).resolve().parent.parent

# Update the output zip file location to save in the output directory in the root
OUTPUT_DIR = PROJECT_ROOT / "output"
OUTPUT_DIR.mkdir(exist_ok=True)
OUTPUT_ZIP = OUTPUT_DIR / "freelance_toolkit.zip"

# Patterns and folders to skip during packaging
# - Includes common system files, caches, virtual environments, and the output zip itself
# - Also excludes the `bin` folder, which contains symlinks or executables
EXCLUDE_NAMES = {
    ".git", "__pycache__", ".venv", "venv", "env",
    ".DS_Store", ".pytest_cache", ".idea", ".mypy_cache",
    "output", "freelance_toolkit.zip", "bin", ".gitignore"
}

# Update the `should_exclude` function to check for `.excluded` marker files
# Function to determine if a file or folder should be excluded
# - Checks if any part of the path matches the exclusion patterns
# - Returns True if the path should be excluded, False otherwise
def should_exclude(path: Path) -> bool:
    # Check for `.excluded` marker file in the directory
    for parent in path.parents:
        if (parent / ".excluded").exists():
            return True
    return any(part in EXCLUDE_NAMES for part in path.parts) or path.name in EXCLUDE_NAMES

# Function to add files to the zip archive
# - Recursively scans the project directory for files
# - Skips files and folders that match the exclusion patterns
# - Adds valid files to the zip archive with their relative paths
def add_files_to_zip(zipf: zipfile.ZipFile, current_dir: Path):
    for item in current_dir.rglob("*"):
        # Skip COMBINED_README.md to avoid duplicate in zip
        if item.is_file() and not should_exclude(item.relative_to(PROJECT_ROOT)) and item.name != "COMBINED_README.md":
            arcname = item.relative_to(PROJECT_ROOT)  # Get the relative path for the archive
            zipf.write(item, arcname)  # Add the file to the zip archive
            print(f"✅ Added: {arcname}")  # Log the added file

# Function to generate a combined README file for the toolkit
# - Summarizes the README files for each tool
# - Dynamically includes new tools without requiring code changes
def generate_combined_readme(output_path: Path):
    combined_readme = []
    combined_readme.append("# Freelance Toolkit\n")
    combined_readme.append("A collection of Python tools for freelancers.\n\n")

    excluded_tools = []

    for tool_dir in PROJECT_ROOT.iterdir():
        if tool_dir.is_dir() and should_exclude(tool_dir):
            excluded_tools.append(tool_dir.name)
            print(f"😜 Excluded Directory: {tool_dir.name}")  # Log excluded tools

    if excluded_tools:
        combined_readme.append("# Excluded Tools\n")
        combined_readme.append("The following tools are excluded from the combined README:\n\n")
        for tool in excluded_tools:
            combined_readme.append(f"- {tool}\n")
        combined_readme.append("\n")

    for tool_dir in PROJECT_ROOT.iterdir():
        if tool_dir.is_dir() and not should_exclude(tool_dir):
            tool_readme = tool_dir / "README.md"
            if tool_readme.exists():
                combined_readme.append(f"## {tool_dir.name.capitalize()}\n")
                with tool_readme.open("r", encoding="utf-8") as f:
                    # Include the first few lines of each tool's README
                    for i, line in enumerate(f):
                        if i >= 10:  # Limit to the first 10 lines
                            combined_readme.append("...\n")
                            break
                        combined_readme.append(line)
                combined_readme.append("\n")

    # Write the combined README to the specified output path
    with output_path.open("w", encoding="utf-8") as f:
        f.writelines(combined_readme)

    if not output_path.exists():
            print("❌ Failed to generate combined README.")
            return

    print(f"\n✅ Combined README generated at: {output_path}")
    
# Main function to create the zip archive
def main():
    # Check if the output zip file already exists
    if OUTPUT_ZIP.exists():
        OUTPUT_ZIP.unlink()  # Remove the existing zip file
        print(f"Deleted old zip: {OUTPUT_ZIP.name}")

    # Generate the combined README file
    combined_readme_path = PROJECT_ROOT / "COMBINED_README.md"
   
    # Check if the old combined README file exists and delete it
    if combined_readme_path.exists():
        combined_readme_path.unlink()
        print(f"Deleted old combined README: {combined_readme_path.name}")

    # Always generate a new combined README file
    generate_combined_readme(combined_readme_path)
        
    # Create a new zip archive
    with zipfile.ZipFile(OUTPUT_ZIP, "w", zipfile.ZIP_DEFLATED) as zipf:
        add_files_to_zip(zipf, PROJECT_ROOT)  # Add files to the archive
        zipf.write(combined_readme_path, "COMBINED_README.md")  # Add the combined README
        print(f"✅ Added: Combined README to zip")  # Log the addition of the combined README
    
    # Remove the temporary combined README file after adding it to the zip
    combined_readme_path.unlink()

    print(f"\n✅ Packaged into: {OUTPUT_ZIP}")  # Log the completion message

# Entry point of the script
if __name__ == "__main__":
    main()
